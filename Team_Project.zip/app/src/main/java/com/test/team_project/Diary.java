package com.test.team_project;

import android.app.Activity;

public class Diary extends Activity {
}
